num1=float (input ("Enter the first number:"))
num2= float (input("Enter the second number :"))
diff=num1+num2
print ("the diff is :", diff)
    


